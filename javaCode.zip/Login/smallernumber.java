
public class smallernumber {

	public static void main(String[] args) {
		int a = 20;
		int b = 15;
		
		if(a<b) {
			System.out.println("a is smaller than b");
		}
		else if(b<a) {
			System.out.println("b is smaller than a");
		}
		else {
			System.out.println("a is equal to b");
		}

	}

}
