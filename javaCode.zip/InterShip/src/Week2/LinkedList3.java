package Week2;
import java.util.*;

public class LinkedList3 {

	public static void main(String[] args) {
		LinkedList<String> list = new LinkedList<String>(); 
		List<String> list1 = new LinkedList<>(); 
		

	}

}
