package GeeksterDSA.Week4;

public class RemoveDuplicate {

	public static void main(String[] args) {
		

	}
	
//	https://leetcode.com/problems/remove-duplicates-from-sorted-list/
	
/*	public ListNode deleteDuplicates(ListNode head) {
        if(head == null){
            return null;
        }
        
        ListNode curr = head.next;
        ListNode prev = head;
        while(curr != null){
            if(curr.val == prev.val){
                prev.next = curr.next;
                curr = curr.next;
            }
            else{
                prev = curr;
                curr = curr.next;
            }
        }
        
        return head;
    }*/

}
