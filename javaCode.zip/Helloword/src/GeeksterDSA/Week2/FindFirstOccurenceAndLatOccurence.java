package GeeksterDSA.Week2;

public class FindFirstOccurenceAndLatOccurence {
	static String s = "abcdeacah";
	public static void FindAccourence(int index,char ch) {
		int first = -1;
		int last = -1;
		
		
	}
	
	public static void main(String[] args) {
		char target = 'a';
		FindAccourence(0,target);

	}

}
