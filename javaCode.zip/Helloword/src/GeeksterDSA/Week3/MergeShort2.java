package GeeksterDSA.Week3;

public class MergeShort2 {

	public static void main(String[] args) {
		int[] arr = {4,6,3,8,2,9,1,10};
		
		
	}

}
