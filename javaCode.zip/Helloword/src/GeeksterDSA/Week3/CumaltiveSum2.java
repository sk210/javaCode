package GeeksterDSA.Week3;

public class CumaltiveSum2 {

	public static void main(String[] args) {
		int[] arr = {0,1,2,3,4,5,6,7};
		int[] cum = new int[arr.length];
		

	}

}
