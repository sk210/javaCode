package GeeksterDSA.Week3;

public class StringToInt {

	public static void main(String[] args) {
		
		String s = "12345";
		char[] ch = s.toCharArray();
		

	}

}
