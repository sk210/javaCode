package Geekster.PracticeSession;

public class ChangeTwoNumber {

	public static void main(String[] args) {
		int a = 6;
		int b = 4;
		
		a = a-b;
		b = a+b;
		a = b-a;
		System.out.println(a);
		System.out.println(b);

	}

}
