package Geekster.PracticeSession;

public class SumOfString {

	public static void main(String[] args) {
		String s = "123";
		String d = "02";

	}

}
