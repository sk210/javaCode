package Geekster.PracticeSession;

public class SplitString {

	public static void main(String[] args) {
		String Str = "Hello; my name is; kaushal";
		String[] result = Str.split("; ");
		System.out.println(result.length);

	}

}
