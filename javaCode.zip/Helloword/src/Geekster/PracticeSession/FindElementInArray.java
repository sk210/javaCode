package Geekster.PracticeSession;

public class FindElementInArray {

	public static void main(String[] args) {
		int[] arr = {4,4,8,8,8,15,16,23,23,42};
		int target = 4;
		

	}

}
