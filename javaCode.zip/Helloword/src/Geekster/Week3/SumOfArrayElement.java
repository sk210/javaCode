package Geekster.Week3;
import java.util.Scanner;

public class SumOfArrayElement {

	public static void main(String[] args) {
		Scanner userinput = new Scanner(System.in);
				
		System.out.print("enter 10 numbers for array : ");
		int[] arr = new int[10];
		int j;
		int sum = 0;
		
		for(int i = 0;i<arr.length;i++) {
			j = userinput.nextInt();
			arr[i] = j;
		}
		
		for(int i = 0;i<arr.length;i++) {
			sum = sum + arr[i];
		}
		
		System.out.print("The sum of Array : " + sum);

	}

}
