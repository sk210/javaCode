package Geekster.Week1;

public class PrintNumber {

	public static void main(String[] args) {
		System.out.println("using for loop print number");
		for(int i = 1; i<=10;i++) {
			System.out.println(i);
		}
		
		System.out.println("");
		System.out.println("using while loop print number");
		
		int k = 1;
		while(k<=10) {
			System.out.println(k);
			k++;
		}

	}

}
