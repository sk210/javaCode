package Geekster.Week1;


public class SmallerNumber {

	public static void main(String[] args) {
		int a = 10;
		int b = 15;
		
		if(a<b) {
			System.out.println("a smaller than b");
		}
		else if(b<a) {
			System.out.println("b smaller than a");
		}
		else {
			System.out.println("a equal to b");
		}

	}

}
