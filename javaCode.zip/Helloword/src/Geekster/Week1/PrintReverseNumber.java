package Geekster.Week1;

public class PrintReverseNumber {

	public static void main(String[] args) {
		System.out.println("using for loop print reverse number");
		for(int i = 10;i >= 1;i--) {
			System.out.println(i);
		}
		
		System.out.println("");
		System.out.println("using while loop print reverse number");
		
		int k = 10;
		while(k>=1) {
			System.out.println(k);
			k--;
		}

	}

}
