package Geekster.Week1;

public class A {
	 public A()
	    {
	        System.out.println("Class A & B");
	    }

}
