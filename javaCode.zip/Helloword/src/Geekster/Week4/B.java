package Geekster.Week4;

import Geekster.Week1.*;

public class B {

	public static void main(String[] args) {
		 A a = new A();

	}

}
