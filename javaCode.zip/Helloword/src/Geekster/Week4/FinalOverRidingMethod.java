package Geekster.Week4;

class Mobile2{
	final public void common() {
		System.out.println("Mobile 2");
	}
}

// cannot override final method from Mobile2
//class OnePlus extends Mobile2{
//	public void common() {
//		System.out.println("OnePlus");
//	}
//}

public class FinalOverRidingMethod {

	public static void main(String[] args) {
//		OnePlus o1 = new OnePlus();
//		o1.common();

	}

}
