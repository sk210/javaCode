
public class Day2Assignment {

	public static void main(String[] args) {
		 System.out.println("Hello World");
  	   System.out.println("Welcome Everyone");
  	  
  	   byte age =21;
  	   short yearOfBearth =2001;
  	   int pincode =464986;
  	   long phoneNumber =9893827994L;
  	   
  	   char section ='K';
  	   String name ="Kaushal Sorathiya";
  	   
  	   int myInt =9;
  	   double myDouble = myInt;
  	   System.out.println(myDouble);
  	   
  	   double myDoubleVar =9.78;
  	   int myIntVar = (int) myDoubleVar;
  	   System.out.println(myIntVar);
  	   
  	   int myNum = 23;
  	   if (myNum % 2 == 0) {
  		   System.out.println("even");
  	   }else {
  		   System.out.println("odd");
  	   }
  	   
  	   System.out.println(1 == 1);//true
  	   System.out.println(1 == 10);//false
  	   System.out.println(1 != 3);//true
  	   System.out.println(3 > 1);//true
  	   System.out.println(1 < 3);//true
  	   System.out.println(1 > 1);//false
  	   System.out.println(1 > 3);//false
  	   System.out.println(1 < 3);//true
  	   
  	   System.out.println(1 <= 1);//true
  	   System.out.println(1 <= 5);//true
  	   System.out.println(6 <= 1);//false
  	   
  	   int myNum2 = 50;
  	   if(myNum2 == 0) {
  		   System.out.println("Zero");
  	 }
  	   else if(myNum2 % 2 == 0) {
  		   System.out.println("even");
  	   }else {
  		   System.out.println("odd");
  	   }
  	   	  
  	   
  	   int num1 = 54;
  	   
  	   if(num1 > 0 && num1 % 2 == 0) {
  		   System.out.println("even positive");
  	   }else if(num1 < 0 && num1 % 2 == 0) {
  		   System.out.println("even negtive");
  	   }else if(num1 == 0) {
  		   System.out.println("Zero");
  	   }else if(num1 < 0 && num1 % 2 == 0) {
  		   System.out.println("odd positive");
  	   }else {
  		   System.out.println("odd negtive");
  	   }
  	   
  	   int num2 = -70;
  	   if(num2 > 0 || num2 < 0) {
  		   System.out.println("not Zero");
  		   }else {
  			   System.out.println("zero");
  		   }
  	   
  	   boolean value = false;
  	   System.out.println(!value);
  	   
  	   int n1 = 20; int n2 = 40;
  	   if(n1>n2) {
  		   System.out.println(n1);
  	   }else {
  		   System.out.println(n2);
  	   }
  	   
  	  // https://github.com/sk210/Kaushal_Day2_Assignment
  	   
  	 

	}

}
