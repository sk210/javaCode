
public class FactorialNumber {

	public static void main(String[] args) {
		int a = 6;
		int Sum = 1;
		while(a>0)
		 {
			Sum=Sum*a;
			a--;
			
		}
		System.out.println("The Factorial Of Number Is " + Sum);
	}

}
