
public class Loop {

	public static void main(String[] args) {
		System.out.println("toady i learn about loop in java");
		
		// for loop
		
		for(int i=0;i<10;i++) {
			System.out.println(i);
		}
		
		
		
		//while loop
		
		int i=0;
		while(i<15) {
			System.out.println(i);
			i++;
		}
		//do while
		i=0;
		do {
			System.out.println(i);
			i++;
		}while(i<30);

	}

}
